const firebaseConfig = {
  apiKey: "AIzaSyBwG0waxRTiTqco8if0G-AM1Ikvq9gkA8Q",
  authDomain: "monitoreoycontroldecultivos.firebaseapp.com",
  databaseURL: "https://monitoreoycontroldecultivos.firebaseio.com",
  projectId: "monitoreoycontroldecultivos",
  storageBucket: "monitoreoycontroldecultivos.appspot.com",
  messagingSenderId: "562628689991",
  appId: "1:562628689991:web:48d039b5c7e4c2b77b3162"
};
export default firebaseConfig;